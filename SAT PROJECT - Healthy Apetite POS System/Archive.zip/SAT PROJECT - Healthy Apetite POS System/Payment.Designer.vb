﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Payment
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.cmdCompletePayment = New System.Windows.Forms.Button()
        Me.cmd5d = New System.Windows.Forms.PictureBox()
        Me.cmd20c = New System.Windows.Forms.PictureBox()
        Me.cd10c = New System.Windows.Forms.PictureBox()
        Me.cmd5c = New System.Windows.Forms.PictureBox()
        Me.cmd50c = New System.Windows.Forms.PictureBox()
        Me.cmd2d = New System.Windows.Forms.PictureBox()
        Me.cmd1d = New System.Windows.Forms.PictureBox()
        Me.cmd10d = New System.Windows.Forms.PictureBox()
        Me.cmd20d = New System.Windows.Forms.PictureBox()
        Me.cmd50d = New System.Windows.Forms.PictureBox()
        Me.cmd100d = New System.Windows.Forms.PictureBox()
        Me.PictureBox6 = New System.Windows.Forms.PictureBox()
        Me.PictureBox7 = New System.Windows.Forms.PictureBox()
        Me.PictureBox8 = New System.Windows.Forms.PictureBox()
        Me.PictureBox9 = New System.Windows.Forms.PictureBox()
        Me.PictureBox10 = New System.Windows.Forms.PictureBox()
        Me.PictureBox11 = New System.Windows.Forms.PictureBox()
        Me.PictureBox12 = New System.Windows.Forms.PictureBox()
        Me.PictureBox13 = New System.Windows.Forms.PictureBox()
        Me.PictureBox14 = New System.Windows.Forms.PictureBox()
        Me.PictureBox15 = New System.Windows.Forms.PictureBox()
        Me.PictureBox16 = New System.Windows.Forms.PictureBox()
        Me.txtAmountOwed = New System.Windows.Forms.TextBox()
        Me.txtAmountPayed = New System.Windows.Forms.TextBox()
        Me.txtDifference = New System.Windows.Forms.TextBox()
        Me.lblAmountOwed = New System.Windows.Forms.Label()
        Me.lblAmountPaid = New System.Windows.Forms.Label()
        Me.lblDifference = New System.Windows.Forms.Label()
        Me.btnGoBack = New System.Windows.Forms.Button()
        Me.txt5c = New System.Windows.Forms.TextBox()
        Me.txt10c = New System.Windows.Forms.TextBox()
        Me.txt20c = New System.Windows.Forms.TextBox()
        Me.txt50c = New System.Windows.Forms.TextBox()
        Me.txt1d = New System.Windows.Forms.TextBox()
        Me.TextBox1 = New System.Windows.Forms.TextBox()
        Me.txt5d = New System.Windows.Forms.TextBox()
        Me.txt10d = New System.Windows.Forms.TextBox()
        Me.txt20d = New System.Windows.Forms.TextBox()
        Me.txt50d = New System.Windows.Forms.TextBox()
        Me.txt100d = New System.Windows.Forms.TextBox()
        CType(Me.cmd5d, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.cmd20c, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.cd10c, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.cmd5c, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.cmd50c, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.cmd2d, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.cmd1d, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.cmd10d, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.cmd20d, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.cmd50d, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.cmd100d, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox6, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox7, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox8, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox9, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox10, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox11, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox12, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox13, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox14, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox15, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox16, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'cmdCompletePayment
        '
        Me.cmdCompletePayment.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmdCompletePayment.Location = New System.Drawing.Point(435, 451)
        Me.cmdCompletePayment.Name = "cmdCompletePayment"
        Me.cmdCompletePayment.Size = New System.Drawing.Size(283, 100)
        Me.cmdCompletePayment.TabIndex = 3
        Me.cmdCompletePayment.Text = "Give Change" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "and" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "Complete Payemt"
        Me.cmdCompletePayment.UseVisualStyleBackColor = True
        '
        'cmd5d
        '
        Me.cmd5d.Image = Global.SAT_PROJECT___Healthy_Apetite_POS_System.My.Resources.Resources._5d
        Me.cmd5d.InitialImage = Nothing
        Me.cmd5d.Location = New System.Drawing.Point(774, 298)
        Me.cmd5d.Name = "cmd5d"
        Me.cmd5d.Size = New System.Drawing.Size(184, 103)
        Me.cmd5d.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.cmd5d.TabIndex = 16
        Me.cmd5d.TabStop = False
        '
        'cmd20c
        '
        Me.cmd20c.Image = Global.SAT_PROJECT___Healthy_Apetite_POS_System.My.Resources.Resources._20c
        Me.cmd20c.InitialImage = Nothing
        Me.cmd20c.Location = New System.Drawing.Point(995, 12)
        Me.cmd20c.Name = "cmd20c"
        Me.cmd20c.Size = New System.Drawing.Size(104, 92)
        Me.cmd20c.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.cmd20c.TabIndex = 9
        Me.cmd20c.TabStop = False
        '
        'cd10c
        '
        Me.cd10c.Image = Global.SAT_PROJECT___Healthy_Apetite_POS_System.My.Resources.Resources._10c
        Me.cd10c.InitialImage = Nothing
        Me.cd10c.Location = New System.Drawing.Point(887, 12)
        Me.cd10c.Name = "cd10c"
        Me.cd10c.Size = New System.Drawing.Size(102, 92)
        Me.cd10c.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.cd10c.TabIndex = 8
        Me.cd10c.TabStop = False
        '
        'cmd5c
        '
        Me.cmd5c.Image = Global.SAT_PROJECT___Healthy_Apetite_POS_System.My.Resources.Resources._5c
        Me.cmd5c.InitialImage = Nothing
        Me.cmd5c.Location = New System.Drawing.Point(778, 12)
        Me.cmd5c.Name = "cmd5c"
        Me.cmd5c.Size = New System.Drawing.Size(103, 92)
        Me.cmd5c.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.cmd5c.TabIndex = 7
        Me.cmd5c.TabStop = False
        '
        'cmd50c
        '
        Me.cmd50c.Image = Global.SAT_PROJECT___Healthy_Apetite_POS_System.My.Resources.Resources._50c
        Me.cmd50c.InitialImage = Nothing
        Me.cmd50c.Location = New System.Drawing.Point(777, 155)
        Me.cmd50c.Name = "cmd50c"
        Me.cmd50c.Size = New System.Drawing.Size(104, 92)
        Me.cmd50c.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.cmd50c.TabIndex = 6
        Me.cmd50c.TabStop = False
        '
        'cmd2d
        '
        Me.cmd2d.Image = Global.SAT_PROJECT___Healthy_Apetite_POS_System.My.Resources.Resources._2d
        Me.cmd2d.InitialImage = Nothing
        Me.cmd2d.Location = New System.Drawing.Point(1000, 155)
        Me.cmd2d.Name = "cmd2d"
        Me.cmd2d.Size = New System.Drawing.Size(99, 92)
        Me.cmd2d.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.cmd2d.TabIndex = 5
        Me.cmd2d.TabStop = False
        '
        'cmd1d
        '
        Me.cmd1d.Image = Global.SAT_PROJECT___Healthy_Apetite_POS_System.My.Resources.Resources._1d
        Me.cmd1d.InitialImage = Nothing
        Me.cmd1d.Location = New System.Drawing.Point(887, 155)
        Me.cmd1d.Name = "cmd1d"
        Me.cmd1d.Size = New System.Drawing.Size(107, 92)
        Me.cmd1d.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.cmd1d.TabIndex = 4
        Me.cmd1d.TabStop = False
        '
        'cmd10d
        '
        Me.cmd10d.Image = Global.SAT_PROJECT___Healthy_Apetite_POS_System.My.Resources.Resources._10d
        Me.cmd10d.InitialImage = Nothing
        Me.cmd10d.Location = New System.Drawing.Point(967, 299)
        Me.cmd10d.Name = "cmd10d"
        Me.cmd10d.Size = New System.Drawing.Size(179, 103)
        Me.cmd10d.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.cmd10d.TabIndex = 17
        Me.cmd10d.TabStop = False
        '
        'cmd20d
        '
        Me.cmd20d.Image = Global.SAT_PROJECT___Healthy_Apetite_POS_System.My.Resources.Resources._20d
        Me.cmd20d.InitialImage = Nothing
        Me.cmd20d.Location = New System.Drawing.Point(779, 451)
        Me.cmd20d.Name = "cmd20d"
        Me.cmd20d.Size = New System.Drawing.Size(179, 103)
        Me.cmd20d.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.cmd20d.TabIndex = 18
        Me.cmd20d.TabStop = False
        '
        'cmd50d
        '
        Me.cmd50d.Image = Global.SAT_PROJECT___Healthy_Apetite_POS_System.My.Resources.Resources._50d
        Me.cmd50d.InitialImage = Nothing
        Me.cmd50d.Location = New System.Drawing.Point(967, 453)
        Me.cmd50d.Name = "cmd50d"
        Me.cmd50d.Size = New System.Drawing.Size(179, 103)
        Me.cmd50d.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.cmd50d.TabIndex = 21
        Me.cmd50d.TabStop = False
        '
        'cmd100d
        '
        Me.cmd100d.Image = Global.SAT_PROJECT___Healthy_Apetite_POS_System.My.Resources.Resources._100d
        Me.cmd100d.InitialImage = Nothing
        Me.cmd100d.Location = New System.Drawing.Point(779, 610)
        Me.cmd100d.Name = "cmd100d"
        Me.cmd100d.Size = New System.Drawing.Size(235, 103)
        Me.cmd100d.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.cmd100d.TabIndex = 22
        Me.cmd100d.TabStop = False
        '
        'PictureBox6
        '
        Me.PictureBox6.Image = Global.SAT_PROJECT___Healthy_Apetite_POS_System.My.Resources.Resources._100d
        Me.PictureBox6.InitialImage = Nothing
        Me.PictureBox6.Location = New System.Drawing.Point(12, 560)
        Me.PictureBox6.Name = "PictureBox6"
        Me.PictureBox6.Size = New System.Drawing.Size(179, 103)
        Me.PictureBox6.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.PictureBox6.TabIndex = 33
        Me.PictureBox6.TabStop = False
        '
        'PictureBox7
        '
        Me.PictureBox7.Image = Global.SAT_PROJECT___Healthy_Apetite_POS_System.My.Resources.Resources._50d
        Me.PictureBox7.InitialImage = Nothing
        Me.PictureBox7.Location = New System.Drawing.Point(200, 453)
        Me.PictureBox7.Name = "PictureBox7"
        Me.PictureBox7.Size = New System.Drawing.Size(179, 103)
        Me.PictureBox7.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.PictureBox7.TabIndex = 32
        Me.PictureBox7.TabStop = False
        '
        'PictureBox8
        '
        Me.PictureBox8.Image = Global.SAT_PROJECT___Healthy_Apetite_POS_System.My.Resources.Resources._20d
        Me.PictureBox8.InitialImage = Nothing
        Me.PictureBox8.Location = New System.Drawing.Point(12, 451)
        Me.PictureBox8.Name = "PictureBox8"
        Me.PictureBox8.Size = New System.Drawing.Size(179, 103)
        Me.PictureBox8.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.PictureBox8.TabIndex = 31
        Me.PictureBox8.TabStop = False
        '
        'PictureBox9
        '
        Me.PictureBox9.Image = Global.SAT_PROJECT___Healthy_Apetite_POS_System.My.Resources.Resources._10d
        Me.PictureBox9.InitialImage = Nothing
        Me.PictureBox9.Location = New System.Drawing.Point(206, 343)
        Me.PictureBox9.Name = "PictureBox9"
        Me.PictureBox9.Size = New System.Drawing.Size(179, 103)
        Me.PictureBox9.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.PictureBox9.TabIndex = 30
        Me.PictureBox9.TabStop = False
        '
        'PictureBox10
        '
        Me.PictureBox10.Image = Global.SAT_PROJECT___Healthy_Apetite_POS_System.My.Resources.Resources._5d
        Me.PictureBox10.InitialImage = Nothing
        Me.PictureBox10.Location = New System.Drawing.Point(13, 342)
        Me.PictureBox10.Name = "PictureBox10"
        Me.PictureBox10.Size = New System.Drawing.Size(184, 103)
        Me.PictureBox10.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.PictureBox10.TabIndex = 29
        Me.PictureBox10.TabStop = False
        '
        'PictureBox11
        '
        Me.PictureBox11.Image = Global.SAT_PROJECT___Healthy_Apetite_POS_System.My.Resources.Resources._20c
        Me.PictureBox11.InitialImage = Nothing
        Me.PictureBox11.Location = New System.Drawing.Point(229, 146)
        Me.PictureBox11.Name = "PictureBox11"
        Me.PictureBox11.Size = New System.Drawing.Size(104, 92)
        Me.PictureBox11.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.PictureBox11.TabIndex = 28
        Me.PictureBox11.TabStop = False
        '
        'PictureBox12
        '
        Me.PictureBox12.Image = Global.SAT_PROJECT___Healthy_Apetite_POS_System.My.Resources.Resources._10c
        Me.PictureBox12.InitialImage = Nothing
        Me.PictureBox12.Location = New System.Drawing.Point(121, 146)
        Me.PictureBox12.Name = "PictureBox12"
        Me.PictureBox12.Size = New System.Drawing.Size(102, 92)
        Me.PictureBox12.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.PictureBox12.TabIndex = 27
        Me.PictureBox12.TabStop = False
        '
        'PictureBox13
        '
        Me.PictureBox13.Image = Global.SAT_PROJECT___Healthy_Apetite_POS_System.My.Resources.Resources._5c
        Me.PictureBox13.InitialImage = Nothing
        Me.PictureBox13.Location = New System.Drawing.Point(12, 146)
        Me.PictureBox13.Name = "PictureBox13"
        Me.PictureBox13.Size = New System.Drawing.Size(103, 92)
        Me.PictureBox13.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.PictureBox13.TabIndex = 26
        Me.PictureBox13.TabStop = False
        '
        'PictureBox14
        '
        Me.PictureBox14.Image = Global.SAT_PROJECT___Healthy_Apetite_POS_System.My.Resources.Resources._50c
        Me.PictureBox14.InitialImage = Nothing
        Me.PictureBox14.Location = New System.Drawing.Point(13, 244)
        Me.PictureBox14.Name = "PictureBox14"
        Me.PictureBox14.Size = New System.Drawing.Size(104, 92)
        Me.PictureBox14.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.PictureBox14.TabIndex = 25
        Me.PictureBox14.TabStop = False
        '
        'PictureBox15
        '
        Me.PictureBox15.Image = Global.SAT_PROJECT___Healthy_Apetite_POS_System.My.Resources.Resources._2d
        Me.PictureBox15.InitialImage = Nothing
        Me.PictureBox15.Location = New System.Drawing.Point(236, 244)
        Me.PictureBox15.Name = "PictureBox15"
        Me.PictureBox15.Size = New System.Drawing.Size(99, 92)
        Me.PictureBox15.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.PictureBox15.TabIndex = 24
        Me.PictureBox15.TabStop = False
        '
        'PictureBox16
        '
        Me.PictureBox16.Image = Global.SAT_PROJECT___Healthy_Apetite_POS_System.My.Resources.Resources._1d
        Me.PictureBox16.InitialImage = Nothing
        Me.PictureBox16.Location = New System.Drawing.Point(123, 244)
        Me.PictureBox16.Name = "PictureBox16"
        Me.PictureBox16.Size = New System.Drawing.Size(107, 92)
        Me.PictureBox16.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.PictureBox16.TabIndex = 23
        Me.PictureBox16.TabStop = False
        '
        'txtAmountOwed
        '
        Me.txtAmountOwed.Font = New System.Drawing.Font("Microsoft Sans Serif", 16.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtAmountOwed.Location = New System.Drawing.Point(435, 110)
        Me.txtAmountOwed.Name = "txtAmountOwed"
        Me.txtAmountOwed.Size = New System.Drawing.Size(309, 44)
        Me.txtAmountOwed.TabIndex = 34
        '
        'txtAmountPayed
        '
        Me.txtAmountPayed.Font = New System.Drawing.Font("Microsoft Sans Serif", 16.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtAmountPayed.Location = New System.Drawing.Point(435, 226)
        Me.txtAmountPayed.Name = "txtAmountPayed"
        Me.txtAmountPayed.Size = New System.Drawing.Size(309, 44)
        Me.txtAmountPayed.TabIndex = 35
        '
        'txtDifference
        '
        Me.txtDifference.Font = New System.Drawing.Font("Microsoft Sans Serif", 16.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtDifference.Location = New System.Drawing.Point(435, 341)
        Me.txtDifference.Name = "txtDifference"
        Me.txtDifference.ReadOnly = True
        Me.txtDifference.Size = New System.Drawing.Size(309, 44)
        Me.txtDifference.TabIndex = 36
        '
        'lblAmountOwed
        '
        Me.lblAmountOwed.AutoSize = True
        Me.lblAmountOwed.Location = New System.Drawing.Point(431, 87)
        Me.lblAmountOwed.Name = "lblAmountOwed"
        Me.lblAmountOwed.Size = New System.Drawing.Size(234, 20)
        Me.lblAmountOwed.TabIndex = 37
        Me.lblAmountOwed.Text = "Amount Owed (From Customer)"
        '
        'lblAmountPaid
        '
        Me.lblAmountPaid.AutoSize = True
        Me.lblAmountPaid.Location = New System.Drawing.Point(431, 203)
        Me.lblAmountPaid.Name = "lblAmountPaid"
        Me.lblAmountPaid.Size = New System.Drawing.Size(205, 20)
        Me.lblAmountPaid.TabIndex = 38
        Me.lblAmountPaid.Text = "Amount Paid (By Customer)"
        '
        'lblDifference
        '
        Me.lblDifference.AutoSize = True
        Me.lblDifference.Location = New System.Drawing.Point(431, 318)
        Me.lblDifference.Name = "lblDifference"
        Me.lblDifference.Size = New System.Drawing.Size(83, 20)
        Me.lblDifference.TabIndex = 39
        Me.lblDifference.Text = "Difference"
        '
        'btnGoBack
        '
        Me.btnGoBack.BackColor = System.Drawing.Color.IndianRed
        Me.btnGoBack.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnGoBack.Location = New System.Drawing.Point(13, 12)
        Me.btnGoBack.Name = "btnGoBack"
        Me.btnGoBack.Size = New System.Drawing.Size(282, 100)
        Me.btnGoBack.TabIndex = 40
        Me.btnGoBack.Text = "Go Back to main screen" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "(amount payed will be reset)"
        Me.btnGoBack.UseVisualStyleBackColor = False
        '
        'txt5c
        '
        Me.txt5c.Font = New System.Drawing.Font("Microsoft Sans Serif", 16.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txt5c.Location = New System.Drawing.Point(779, 105)
        Me.txt5c.Name = "txt5c"
        Me.txt5c.ReadOnly = True
        Me.txt5c.Size = New System.Drawing.Size(102, 44)
        Me.txt5c.TabIndex = 41
        '
        'txt10c
        '
        Me.txt10c.Font = New System.Drawing.Font("Microsoft Sans Serif", 16.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txt10c.Location = New System.Drawing.Point(887, 105)
        Me.txt10c.Name = "txt10c"
        Me.txt10c.ReadOnly = True
        Me.txt10c.Size = New System.Drawing.Size(102, 44)
        Me.txt10c.TabIndex = 42
        '
        'txt20c
        '
        Me.txt20c.Font = New System.Drawing.Font("Microsoft Sans Serif", 16.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txt20c.Location = New System.Drawing.Point(995, 105)
        Me.txt20c.Name = "txt20c"
        Me.txt20c.ReadOnly = True
        Me.txt20c.Size = New System.Drawing.Size(102, 44)
        Me.txt20c.TabIndex = 43
        '
        'txt50c
        '
        Me.txt50c.Font = New System.Drawing.Font("Microsoft Sans Serif", 16.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txt50c.Location = New System.Drawing.Point(777, 248)
        Me.txt50c.Name = "txt50c"
        Me.txt50c.ReadOnly = True
        Me.txt50c.Size = New System.Drawing.Size(102, 44)
        Me.txt50c.TabIndex = 44
        '
        'txt1d
        '
        Me.txt1d.Font = New System.Drawing.Font("Microsoft Sans Serif", 16.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txt1d.Location = New System.Drawing.Point(887, 248)
        Me.txt1d.Name = "txt1d"
        Me.txt1d.ReadOnly = True
        Me.txt1d.Size = New System.Drawing.Size(102, 44)
        Me.txt1d.TabIndex = 45
        '
        'TextBox1
        '
        Me.TextBox1.Font = New System.Drawing.Font("Microsoft Sans Serif", 16.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBox1.Location = New System.Drawing.Point(1000, 248)
        Me.TextBox1.Name = "TextBox1"
        Me.TextBox1.ReadOnly = True
        Me.TextBox1.Size = New System.Drawing.Size(102, 44)
        Me.TextBox1.TabIndex = 46
        '
        'txt5d
        '
        Me.txt5d.Font = New System.Drawing.Font("Microsoft Sans Serif", 16.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txt5d.Location = New System.Drawing.Point(774, 402)
        Me.txt5d.Name = "txt5d"
        Me.txt5d.ReadOnly = True
        Me.txt5d.Size = New System.Drawing.Size(184, 44)
        Me.txt5d.TabIndex = 47
        '
        'txt10d
        '
        Me.txt10d.Font = New System.Drawing.Font("Microsoft Sans Serif", 16.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txt10d.Location = New System.Drawing.Point(967, 403)
        Me.txt10d.Name = "txt10d"
        Me.txt10d.ReadOnly = True
        Me.txt10d.Size = New System.Drawing.Size(179, 44)
        Me.txt10d.TabIndex = 48
        '
        'txt20d
        '
        Me.txt20d.Font = New System.Drawing.Font("Microsoft Sans Serif", 16.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txt20d.Location = New System.Drawing.Point(779, 560)
        Me.txt20d.Name = "txt20d"
        Me.txt20d.ReadOnly = True
        Me.txt20d.Size = New System.Drawing.Size(179, 44)
        Me.txt20d.TabIndex = 49
        '
        'txt50d
        '
        Me.txt50d.Font = New System.Drawing.Font("Microsoft Sans Serif", 16.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txt50d.Location = New System.Drawing.Point(967, 562)
        Me.txt50d.Name = "txt50d"
        Me.txt50d.ReadOnly = True
        Me.txt50d.Size = New System.Drawing.Size(179, 44)
        Me.txt50d.TabIndex = 50
        '
        'txt100d
        '
        Me.txt100d.Font = New System.Drawing.Font("Microsoft Sans Serif", 16.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txt100d.Location = New System.Drawing.Point(1020, 638)
        Me.txt100d.Name = "txt100d"
        Me.txt100d.ReadOnly = True
        Me.txt100d.Size = New System.Drawing.Size(128, 44)
        Me.txt100d.TabIndex = 51
        '
        'Payment
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(9.0!, 20.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(1175, 725)
        Me.Controls.Add(Me.txt100d)
        Me.Controls.Add(Me.txt50d)
        Me.Controls.Add(Me.txt20d)
        Me.Controls.Add(Me.txt10d)
        Me.Controls.Add(Me.txt5d)
        Me.Controls.Add(Me.TextBox1)
        Me.Controls.Add(Me.txt1d)
        Me.Controls.Add(Me.txt50c)
        Me.Controls.Add(Me.txt20c)
        Me.Controls.Add(Me.txt10c)
        Me.Controls.Add(Me.txt5c)
        Me.Controls.Add(Me.btnGoBack)
        Me.Controls.Add(Me.lblDifference)
        Me.Controls.Add(Me.lblAmountPaid)
        Me.Controls.Add(Me.lblAmountOwed)
        Me.Controls.Add(Me.txtDifference)
        Me.Controls.Add(Me.txtAmountPayed)
        Me.Controls.Add(Me.txtAmountOwed)
        Me.Controls.Add(Me.PictureBox6)
        Me.Controls.Add(Me.PictureBox7)
        Me.Controls.Add(Me.PictureBox8)
        Me.Controls.Add(Me.PictureBox9)
        Me.Controls.Add(Me.PictureBox10)
        Me.Controls.Add(Me.PictureBox11)
        Me.Controls.Add(Me.PictureBox12)
        Me.Controls.Add(Me.PictureBox13)
        Me.Controls.Add(Me.PictureBox14)
        Me.Controls.Add(Me.PictureBox15)
        Me.Controls.Add(Me.PictureBox16)
        Me.Controls.Add(Me.cmd100d)
        Me.Controls.Add(Me.cmd50d)
        Me.Controls.Add(Me.cmd20d)
        Me.Controls.Add(Me.cmd10d)
        Me.Controls.Add(Me.cmd5d)
        Me.Controls.Add(Me.cmd20c)
        Me.Controls.Add(Me.cd10c)
        Me.Controls.Add(Me.cmd5c)
        Me.Controls.Add(Me.cmd50c)
        Me.Controls.Add(Me.cmd2d)
        Me.Controls.Add(Me.cmd1d)
        Me.Controls.Add(Me.cmdCompletePayment)
        Me.Name = "Payment"
        Me.Text = "Payment Menu"
        CType(Me.cmd5d, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.cmd20c, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.cd10c, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.cmd5c, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.cmd50c, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.cmd2d, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.cmd1d, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.cmd10d, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.cmd20d, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.cmd50d, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.cmd100d, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox6, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox7, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox8, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox9, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox10, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox11, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox12, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox13, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox14, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox15, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox16, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents cmdCompletePayment As Button
    Friend WithEvents cmd1d As PictureBox
    Friend WithEvents cmd2d As PictureBox
    Friend WithEvents cmd50c As PictureBox
    Friend WithEvents cmd20c As PictureBox
    Friend WithEvents cd10c As PictureBox
    Friend WithEvents cmd5c As PictureBox
    Friend WithEvents cmd5d As PictureBox
    Friend WithEvents cmd10d As PictureBox
    Friend WithEvents cmd20d As PictureBox
    Friend WithEvents cmd50d As PictureBox
    Friend WithEvents cmd100d As PictureBox
    Friend WithEvents PictureBox6 As PictureBox
    Friend WithEvents PictureBox7 As PictureBox
    Friend WithEvents PictureBox8 As PictureBox
    Friend WithEvents PictureBox9 As PictureBox
    Friend WithEvents PictureBox10 As PictureBox
    Friend WithEvents PictureBox11 As PictureBox
    Friend WithEvents PictureBox12 As PictureBox
    Friend WithEvents PictureBox13 As PictureBox
    Friend WithEvents PictureBox14 As PictureBox
    Friend WithEvents PictureBox15 As PictureBox
    Friend WithEvents PictureBox16 As PictureBox
    Friend WithEvents txtAmountOwed As TextBox
    Friend WithEvents txtAmountPayed As TextBox
    Friend WithEvents txtDifference As TextBox
    Friend WithEvents lblAmountOwed As Label
    Friend WithEvents lblAmountPaid As Label
    Friend WithEvents lblDifference As Label
    Friend WithEvents btnGoBack As Button
    Friend WithEvents txt5c As TextBox
    Friend WithEvents txt10c As TextBox
    Friend WithEvents txt20c As TextBox
    Friend WithEvents txt50c As TextBox
    Friend WithEvents txt1d As TextBox
    Friend WithEvents TextBox1 As TextBox
    Friend WithEvents txt5d As TextBox
    Friend WithEvents txt10d As TextBox
    Friend WithEvents txt20d As TextBox
    Friend WithEvents txt50d As TextBox
    Friend WithEvents txt100d As TextBox
End Class

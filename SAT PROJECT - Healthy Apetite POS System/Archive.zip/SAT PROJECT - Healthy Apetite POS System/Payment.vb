﻿Public Class Payment

    Private Sub btnGoBack_Click(sender As Object, e As EventArgs) Handles btnGoBack.Click
        'close this window
    End Sub

    Private Sub txtAmountOwed_TextChanged(sender As Object, e As EventArgs) Handles txtAmountOwed.TextChanged
        CalculateDifference()
    End Sub

    Private Sub txtAmountPayed_TextChanged(sender As Object, e As EventArgs) Handles txtAmountPayed.TextChanged
        CalculateDifference()
    End Sub

    Private Sub CalculateDifference()
        Dim AmtOwed As Integer = Val(txtAmountOwed.Text)
        Dim AmtPaid As Integer = Val(txtAmountPayed.Text)
        Dim Difference As Integer

        Difference = AmtOwed - AmtPaid

        txtDifference.Text = CStr(Difference)
    End Sub

#Region "Notes To Self"

#End Region

#Region "What Dis Do?"

    'txtAmountOwed:
    'This text box shows the amount owed by the customer based on what they have in their cart

    'txtAmountPayed:
    'Shows the amount payed by the customer

    'txtDifference:
    'Shows the difference in amount payed and owed
    'depending on weather it is negative or positive, shows weather the customer owes money or
    'weather the cashier owes the customer money

    'cmdCompletePayment:
    'When the customer has payed what they have owed, then this button will
    'complete the payment

#End Region

End Class
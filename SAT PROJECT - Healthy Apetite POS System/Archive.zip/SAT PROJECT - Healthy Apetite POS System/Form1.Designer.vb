﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.pnlProducts = New System.Windows.Forms.Panel()
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.Panel2 = New System.Windows.Forms.Panel()
        Me.cmd1_1 = New System.Windows.Forms.Button()
        Me.Button2 = New System.Windows.Forms.Button()
        Me.Button3 = New System.Windows.Forms.Button()
        Me.Button4 = New System.Windows.Forms.Button()
        Me.Button5 = New System.Windows.Forms.Button()
        Me.Button6 = New System.Windows.Forms.Button()
        Me.Button7 = New System.Windows.Forms.Button()
        Me.Button8 = New System.Windows.Forms.Button()
        Me.Button9 = New System.Windows.Forms.Button()
        Me.Button10 = New System.Windows.Forms.Button()
        Me.Button11 = New System.Windows.Forms.Button()
        Me.Button12 = New System.Windows.Forms.Button()
        Me.Button13 = New System.Windows.Forms.Button()
        Me.Button14 = New System.Windows.Forms.Button()
        Me.Button15 = New System.Windows.Forms.Button()
        Me.cmd1_2 = New System.Windows.Forms.Button()
        Me.Button17 = New System.Windows.Forms.Button()
        Me.Button18 = New System.Windows.Forms.Button()
        Me.Button19 = New System.Windows.Forms.Button()
        Me.Button20 = New System.Windows.Forms.Button()
        Me.Button21 = New System.Windows.Forms.Button()
        Me.Button22 = New System.Windows.Forms.Button()
        Me.Button23 = New System.Windows.Forms.Button()
        Me.cmd1_4 = New System.Windows.Forms.Button()
        Me.Button25 = New System.Windows.Forms.Button()
        Me.Button26 = New System.Windows.Forms.Button()
        Me.Button27 = New System.Windows.Forms.Button()
        Me.Button28 = New System.Windows.Forms.Button()
        Me.Button29 = New System.Windows.Forms.Button()
        Me.Button30 = New System.Windows.Forms.Button()
        Me.Button31 = New System.Windows.Forms.Button()
        Me.cmd1_3 = New System.Windows.Forms.Button()
        Me.cmdEditItems = New System.Windows.Forms.Button()
        Me.cmdClearOrder = New System.Windows.Forms.Button()
        Me.cmdBeginEndShift = New System.Windows.Forms.Button()
        Me.cmdCash = New System.Windows.Forms.Button()
        Me.cmdCard = New System.Windows.Forms.Button()
        Me.cmdDiscount = New System.Windows.Forms.Button()
        Me.txtCart = New System.Windows.Forms.TextBox()
        Me.lblLabelTotalCost = New System.Windows.Forms.Label()
        Me.lblTotalCost = New System.Windows.Forms.Label()
        Me.grpCart = New System.Windows.Forms.GroupBox()
        Me.grpFunctions = New System.Windows.Forms.GroupBox()
        Me.grpItems = New System.Windows.Forms.GroupBox()
        Me.pnlProducts.SuspendLayout()
        Me.Panel1.SuspendLayout()
        Me.Panel2.SuspendLayout()
        Me.grpCart.SuspendLayout()
        Me.grpFunctions.SuspendLayout()
        Me.grpItems.SuspendLayout()
        Me.SuspendLayout()
        '
        'pnlProducts
        '
        Me.pnlProducts.Controls.Add(Me.Button17)
        Me.pnlProducts.Controls.Add(Me.Button18)
        Me.pnlProducts.Controls.Add(Me.Button19)
        Me.pnlProducts.Controls.Add(Me.Button20)
        Me.pnlProducts.Controls.Add(Me.Button21)
        Me.pnlProducts.Controls.Add(Me.Button22)
        Me.pnlProducts.Controls.Add(Me.Button23)
        Me.pnlProducts.Controls.Add(Me.cmd1_4)
        Me.pnlProducts.Controls.Add(Me.Button25)
        Me.pnlProducts.Controls.Add(Me.Button26)
        Me.pnlProducts.Controls.Add(Me.Button27)
        Me.pnlProducts.Controls.Add(Me.Button28)
        Me.pnlProducts.Controls.Add(Me.Button29)
        Me.pnlProducts.Controls.Add(Me.Button30)
        Me.pnlProducts.Controls.Add(Me.Button31)
        Me.pnlProducts.Controls.Add(Me.cmd1_3)
        Me.pnlProducts.Controls.Add(Me.Button9)
        Me.pnlProducts.Controls.Add(Me.Button10)
        Me.pnlProducts.Controls.Add(Me.Button11)
        Me.pnlProducts.Controls.Add(Me.Button12)
        Me.pnlProducts.Controls.Add(Me.Button13)
        Me.pnlProducts.Controls.Add(Me.Button14)
        Me.pnlProducts.Controls.Add(Me.Button15)
        Me.pnlProducts.Controls.Add(Me.cmd1_2)
        Me.pnlProducts.Controls.Add(Me.Button5)
        Me.pnlProducts.Controls.Add(Me.Button6)
        Me.pnlProducts.Controls.Add(Me.Button7)
        Me.pnlProducts.Controls.Add(Me.Button8)
        Me.pnlProducts.Controls.Add(Me.Button3)
        Me.pnlProducts.Controls.Add(Me.Button4)
        Me.pnlProducts.Controls.Add(Me.Button2)
        Me.pnlProducts.Controls.Add(Me.cmd1_1)
        Me.pnlProducts.Location = New System.Drawing.Point(11, 25)
        Me.pnlProducts.Name = "pnlProducts"
        Me.pnlProducts.Size = New System.Drawing.Size(532, 613)
        Me.pnlProducts.TabIndex = 0
        '
        'Panel1
        '
        Me.Panel1.Controls.Add(Me.lblTotalCost)
        Me.Panel1.Controls.Add(Me.lblLabelTotalCost)
        Me.Panel1.Controls.Add(Me.txtCart)
        Me.Panel1.Location = New System.Drawing.Point(6, 25)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(532, 397)
        Me.Panel1.TabIndex = 1
        '
        'Panel2
        '
        Me.Panel2.Controls.Add(Me.cmdCash)
        Me.Panel2.Controls.Add(Me.cmdCard)
        Me.Panel2.Controls.Add(Me.cmdDiscount)
        Me.Panel2.Controls.Add(Me.cmdBeginEndShift)
        Me.Panel2.Controls.Add(Me.cmdClearOrder)
        Me.Panel2.Controls.Add(Me.cmdEditItems)
        Me.Panel2.Location = New System.Drawing.Point(5, 25)
        Me.Panel2.Name = "Panel2"
        Me.Panel2.Size = New System.Drawing.Size(532, 210)
        Me.Panel2.TabIndex = 2
        '
        'cmd1_1
        '
        Me.cmd1_1.Location = New System.Drawing.Point(3, 3)
        Me.cmd1_1.Name = "cmd1_1"
        Me.cmd1_1.Size = New System.Drawing.Size(130, 75)
        Me.cmd1_1.TabIndex = 0
        Me.cmd1_1.Text = "Button1"
        Me.cmd1_1.UseVisualStyleBackColor = True
        '
        'Button2
        '
        Me.Button2.Location = New System.Drawing.Point(3, 79)
        Me.Button2.Name = "Button2"
        Me.Button2.Size = New System.Drawing.Size(130, 75)
        Me.Button2.TabIndex = 1
        Me.Button2.Text = "Button2"
        Me.Button2.UseVisualStyleBackColor = True
        '
        'Button3
        '
        Me.Button3.Location = New System.Drawing.Point(3, 231)
        Me.Button3.Name = "Button3"
        Me.Button3.Size = New System.Drawing.Size(130, 75)
        Me.Button3.TabIndex = 3
        Me.Button3.Text = "Button3"
        Me.Button3.UseVisualStyleBackColor = True
        '
        'Button4
        '
        Me.Button4.Location = New System.Drawing.Point(3, 155)
        Me.Button4.Name = "Button4"
        Me.Button4.Size = New System.Drawing.Size(130, 75)
        Me.Button4.TabIndex = 2
        Me.Button4.Text = "Button4"
        Me.Button4.UseVisualStyleBackColor = True
        '
        'Button5
        '
        Me.Button5.Location = New System.Drawing.Point(3, 535)
        Me.Button5.Name = "Button5"
        Me.Button5.Size = New System.Drawing.Size(130, 75)
        Me.Button5.TabIndex = 7
        Me.Button5.Text = "Button5"
        Me.Button5.UseVisualStyleBackColor = True
        '
        'Button6
        '
        Me.Button6.Location = New System.Drawing.Point(3, 459)
        Me.Button6.Name = "Button6"
        Me.Button6.Size = New System.Drawing.Size(130, 75)
        Me.Button6.TabIndex = 6
        Me.Button6.Text = "Button6"
        Me.Button6.UseVisualStyleBackColor = True
        '
        'Button7
        '
        Me.Button7.Location = New System.Drawing.Point(3, 383)
        Me.Button7.Name = "Button7"
        Me.Button7.Size = New System.Drawing.Size(130, 75)
        Me.Button7.TabIndex = 5
        Me.Button7.Text = "Button7"
        Me.Button7.UseVisualStyleBackColor = True
        '
        'Button8
        '
        Me.Button8.Location = New System.Drawing.Point(3, 307)
        Me.Button8.Name = "Button8"
        Me.Button8.Size = New System.Drawing.Size(130, 75)
        Me.Button8.TabIndex = 4
        Me.Button8.Text = "Button8"
        Me.Button8.UseVisualStyleBackColor = True
        '
        'Button9
        '
        Me.Button9.Location = New System.Drawing.Point(134, 535)
        Me.Button9.Name = "Button9"
        Me.Button9.Size = New System.Drawing.Size(130, 75)
        Me.Button9.TabIndex = 15
        Me.Button9.Text = "Button9"
        Me.Button9.UseVisualStyleBackColor = True
        '
        'Button10
        '
        Me.Button10.Location = New System.Drawing.Point(134, 459)
        Me.Button10.Name = "Button10"
        Me.Button10.Size = New System.Drawing.Size(130, 75)
        Me.Button10.TabIndex = 14
        Me.Button10.Text = "Button10"
        Me.Button10.UseVisualStyleBackColor = True
        '
        'Button11
        '
        Me.Button11.Location = New System.Drawing.Point(134, 383)
        Me.Button11.Name = "Button11"
        Me.Button11.Size = New System.Drawing.Size(130, 75)
        Me.Button11.TabIndex = 13
        Me.Button11.Text = "Button11"
        Me.Button11.UseVisualStyleBackColor = True
        '
        'Button12
        '
        Me.Button12.Location = New System.Drawing.Point(134, 307)
        Me.Button12.Name = "Button12"
        Me.Button12.Size = New System.Drawing.Size(130, 75)
        Me.Button12.TabIndex = 12
        Me.Button12.Text = "Button12"
        Me.Button12.UseVisualStyleBackColor = True
        '
        'Button13
        '
        Me.Button13.Location = New System.Drawing.Point(134, 231)
        Me.Button13.Name = "Button13"
        Me.Button13.Size = New System.Drawing.Size(130, 75)
        Me.Button13.TabIndex = 11
        Me.Button13.Text = "Button13"
        Me.Button13.UseVisualStyleBackColor = True
        '
        'Button14
        '
        Me.Button14.Location = New System.Drawing.Point(134, 155)
        Me.Button14.Name = "Button14"
        Me.Button14.Size = New System.Drawing.Size(130, 75)
        Me.Button14.TabIndex = 10
        Me.Button14.Text = "Button14"
        Me.Button14.UseVisualStyleBackColor = True
        '
        'Button15
        '
        Me.Button15.Location = New System.Drawing.Point(134, 79)
        Me.Button15.Name = "Button15"
        Me.Button15.Size = New System.Drawing.Size(130, 75)
        Me.Button15.TabIndex = 9
        Me.Button15.Text = "Button15"
        Me.Button15.UseVisualStyleBackColor = True
        '
        'cmd1_2
        '
        Me.cmd1_2.Location = New System.Drawing.Point(134, 3)
        Me.cmd1_2.Name = "cmd1_2"
        Me.cmd1_2.Size = New System.Drawing.Size(130, 75)
        Me.cmd1_2.TabIndex = 8
        Me.cmd1_2.Text = "Button16"
        Me.cmd1_2.UseVisualStyleBackColor = True
        '
        'Button17
        '
        Me.Button17.Location = New System.Drawing.Point(396, 535)
        Me.Button17.Name = "Button17"
        Me.Button17.Size = New System.Drawing.Size(130, 75)
        Me.Button17.TabIndex = 31
        Me.Button17.Text = "Button17"
        Me.Button17.UseVisualStyleBackColor = True
        '
        'Button18
        '
        Me.Button18.Location = New System.Drawing.Point(396, 459)
        Me.Button18.Name = "Button18"
        Me.Button18.Size = New System.Drawing.Size(130, 75)
        Me.Button18.TabIndex = 30
        Me.Button18.Text = "Button18"
        Me.Button18.UseVisualStyleBackColor = True
        '
        'Button19
        '
        Me.Button19.Location = New System.Drawing.Point(396, 383)
        Me.Button19.Name = "Button19"
        Me.Button19.Size = New System.Drawing.Size(130, 75)
        Me.Button19.TabIndex = 29
        Me.Button19.Text = "Button19"
        Me.Button19.UseVisualStyleBackColor = True
        '
        'Button20
        '
        Me.Button20.Location = New System.Drawing.Point(396, 307)
        Me.Button20.Name = "Button20"
        Me.Button20.Size = New System.Drawing.Size(130, 75)
        Me.Button20.TabIndex = 28
        Me.Button20.Text = "Button20"
        Me.Button20.UseVisualStyleBackColor = True
        '
        'Button21
        '
        Me.Button21.Location = New System.Drawing.Point(396, 231)
        Me.Button21.Name = "Button21"
        Me.Button21.Size = New System.Drawing.Size(130, 75)
        Me.Button21.TabIndex = 27
        Me.Button21.Text = "Button21"
        Me.Button21.UseVisualStyleBackColor = True
        '
        'Button22
        '
        Me.Button22.Location = New System.Drawing.Point(396, 155)
        Me.Button22.Name = "Button22"
        Me.Button22.Size = New System.Drawing.Size(130, 75)
        Me.Button22.TabIndex = 26
        Me.Button22.Text = "Button22"
        Me.Button22.UseVisualStyleBackColor = True
        '
        'Button23
        '
        Me.Button23.Location = New System.Drawing.Point(396, 79)
        Me.Button23.Name = "Button23"
        Me.Button23.Size = New System.Drawing.Size(130, 75)
        Me.Button23.TabIndex = 25
        Me.Button23.Text = "Button23"
        Me.Button23.UseVisualStyleBackColor = True
        '
        'cmd1_4
        '
        Me.cmd1_4.Location = New System.Drawing.Point(396, 3)
        Me.cmd1_4.Name = "cmd1_4"
        Me.cmd1_4.Size = New System.Drawing.Size(130, 75)
        Me.cmd1_4.TabIndex = 24
        Me.cmd1_4.Text = "Button24"
        Me.cmd1_4.UseVisualStyleBackColor = True
        '
        'Button25
        '
        Me.Button25.Location = New System.Drawing.Point(265, 535)
        Me.Button25.Name = "Button25"
        Me.Button25.Size = New System.Drawing.Size(130, 75)
        Me.Button25.TabIndex = 23
        Me.Button25.Text = "Button25"
        Me.Button25.UseVisualStyleBackColor = True
        '
        'Button26
        '
        Me.Button26.Location = New System.Drawing.Point(265, 459)
        Me.Button26.Name = "Button26"
        Me.Button26.Size = New System.Drawing.Size(130, 75)
        Me.Button26.TabIndex = 22
        Me.Button26.Text = "Button26"
        Me.Button26.UseVisualStyleBackColor = True
        '
        'Button27
        '
        Me.Button27.Location = New System.Drawing.Point(265, 383)
        Me.Button27.Name = "Button27"
        Me.Button27.Size = New System.Drawing.Size(130, 75)
        Me.Button27.TabIndex = 21
        Me.Button27.Text = "Button27"
        Me.Button27.UseVisualStyleBackColor = True
        '
        'Button28
        '
        Me.Button28.Location = New System.Drawing.Point(265, 307)
        Me.Button28.Name = "Button28"
        Me.Button28.Size = New System.Drawing.Size(130, 75)
        Me.Button28.TabIndex = 20
        Me.Button28.Text = "Button28"
        Me.Button28.UseVisualStyleBackColor = True
        '
        'Button29
        '
        Me.Button29.Location = New System.Drawing.Point(265, 231)
        Me.Button29.Name = "Button29"
        Me.Button29.Size = New System.Drawing.Size(130, 75)
        Me.Button29.TabIndex = 19
        Me.Button29.Text = "Button29"
        Me.Button29.UseVisualStyleBackColor = True
        '
        'Button30
        '
        Me.Button30.Location = New System.Drawing.Point(265, 155)
        Me.Button30.Name = "Button30"
        Me.Button30.Size = New System.Drawing.Size(130, 75)
        Me.Button30.TabIndex = 18
        Me.Button30.Text = "Button30"
        Me.Button30.UseVisualStyleBackColor = True
        '
        'Button31
        '
        Me.Button31.Location = New System.Drawing.Point(265, 79)
        Me.Button31.Name = "Button31"
        Me.Button31.Size = New System.Drawing.Size(130, 75)
        Me.Button31.TabIndex = 17
        Me.Button31.Text = "Button31"
        Me.Button31.UseVisualStyleBackColor = True
        '
        'cmd1_3
        '
        Me.cmd1_3.Location = New System.Drawing.Point(265, 3)
        Me.cmd1_3.Name = "cmd1_3"
        Me.cmd1_3.Size = New System.Drawing.Size(130, 75)
        Me.cmd1_3.TabIndex = 16
        Me.cmd1_3.Text = "Button32"
        Me.cmd1_3.UseVisualStyleBackColor = True
        '
        'cmdEditItems
        '
        Me.cmdEditItems.Location = New System.Drawing.Point(3, 3)
        Me.cmdEditItems.Name = "cmdEditItems"
        Me.cmdEditItems.Size = New System.Drawing.Size(171, 99)
        Me.cmdEditItems.TabIndex = 39
        Me.cmdEditItems.Text = "EDIT ITEMS"
        Me.cmdEditItems.UseVisualStyleBackColor = True
        '
        'cmdClearOrder
        '
        Me.cmdClearOrder.Location = New System.Drawing.Point(180, 3)
        Me.cmdClearOrder.Name = "cmdClearOrder"
        Me.cmdClearOrder.Size = New System.Drawing.Size(171, 99)
        Me.cmdClearOrder.TabIndex = 41
        Me.cmdClearOrder.Text = "CLEAR ORDER" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "or" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "CANCEL ORDER"
        Me.cmdClearOrder.UseVisualStyleBackColor = True
        '
        'cmdBeginEndShift
        '
        Me.cmdBeginEndShift.Location = New System.Drawing.Point(357, 3)
        Me.cmdBeginEndShift.Name = "cmdBeginEndShift"
        Me.cmdBeginEndShift.Size = New System.Drawing.Size(171, 99)
        Me.cmdBeginEndShift.TabIndex = 42
        Me.cmdBeginEndShift.Text = "BEGIN / END SHIFT"
        Me.cmdBeginEndShift.UseVisualStyleBackColor = True
        '
        'cmdCash
        '
        Me.cmdCash.Location = New System.Drawing.Point(357, 108)
        Me.cmdCash.Name = "cmdCash"
        Me.cmdCash.Size = New System.Drawing.Size(171, 99)
        Me.cmdCash.TabIndex = 45
        Me.cmdCash.Text = "CASH"
        Me.cmdCash.UseVisualStyleBackColor = True
        '
        'cmdCard
        '
        Me.cmdCard.Location = New System.Drawing.Point(180, 108)
        Me.cmdCard.Name = "cmdCard"
        Me.cmdCard.Size = New System.Drawing.Size(171, 99)
        Me.cmdCard.TabIndex = 44
        Me.cmdCard.Text = "CARD"
        Me.cmdCard.UseVisualStyleBackColor = True
        '
        'cmdDiscount
        '
        Me.cmdDiscount.Location = New System.Drawing.Point(3, 108)
        Me.cmdDiscount.Name = "cmdDiscount"
        Me.cmdDiscount.Size = New System.Drawing.Size(171, 99)
        Me.cmdDiscount.TabIndex = 43
        Me.cmdDiscount.Text = "DISCOUNT"
        Me.cmdDiscount.UseVisualStyleBackColor = True
        '
        'txtCart
        '
        Me.txtCart.Location = New System.Drawing.Point(3, 3)
        Me.txtCart.Multiline = True
        Me.txtCart.Name = "txtCart"
        Me.txtCart.ScrollBars = System.Windows.Forms.ScrollBars.Vertical
        Me.txtCart.Size = New System.Drawing.Size(526, 346)
        Me.txtCart.TabIndex = 0
        Me.txtCart.Text = "1" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "2" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "3" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "4" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "5" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "6" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "7" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "8" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "9" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "10" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "11" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "12" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "13" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "14" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "15" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "16" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "17" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "18" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "19" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "20"
        '
        'lblLabelTotalCost
        '
        Me.lblLabelTotalCost.AutoSize = True
        Me.lblLabelTotalCost.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblLabelTotalCost.Location = New System.Drawing.Point(3, 358)
        Me.lblLabelTotalCost.Name = "lblLabelTotalCost"
        Me.lblLabelTotalCost.Size = New System.Drawing.Size(129, 29)
        Me.lblLabelTotalCost.TabIndex = 2
        Me.lblLabelTotalCost.Text = "Total Cost:"
        '
        'lblTotalCost
        '
        Me.lblTotalCost.AutoSize = True
        Me.lblTotalCost.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblTotalCost.Font = New System.Drawing.Font("Microsoft Sans Serif", 16.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblTotalCost.Location = New System.Drawing.Point(138, 352)
        Me.lblTotalCost.Name = "lblTotalCost"
        Me.lblTotalCost.Size = New System.Drawing.Size(360, 39)
        Me.lblTotalCost.TabIndex = 3
        Me.lblTotalCost.Text = "* TOTAL COST HERE *"
        '
        'grpCart
        '
        Me.grpCart.Controls.Add(Me.Panel1)
        Me.grpCart.Location = New System.Drawing.Point(12, 12)
        Me.grpCart.Name = "grpCart"
        Me.grpCart.Size = New System.Drawing.Size(543, 428)
        Me.grpCart.TabIndex = 3
        Me.grpCart.TabStop = False
        Me.grpCart.Text = "CART"
        '
        'grpFunctions
        '
        Me.grpFunctions.Controls.Add(Me.Panel2)
        Me.grpFunctions.Location = New System.Drawing.Point(12, 446)
        Me.grpFunctions.Name = "grpFunctions"
        Me.grpFunctions.Size = New System.Drawing.Size(543, 244)
        Me.grpFunctions.TabIndex = 4
        Me.grpFunctions.TabStop = False
        Me.grpFunctions.Text = "FUNCTIONS"
        '
        'grpItems
        '
        Me.grpItems.Controls.Add(Me.pnlProducts)
        Me.grpItems.Location = New System.Drawing.Point(572, 12)
        Me.grpItems.Name = "grpItems"
        Me.grpItems.Size = New System.Drawing.Size(557, 677)
        Me.grpItems.TabIndex = 5
        Me.grpItems.TabStop = False
        Me.grpItems.Text = "ITEMS"
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(9.0!, 20.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(1160, 702)
        Me.Controls.Add(Me.grpItems)
        Me.Controls.Add(Me.grpFunctions)
        Me.Controls.Add(Me.grpCart)
        Me.Name = "Form1"
        Me.Text = "Main Screen"
        Me.pnlProducts.ResumeLayout(False)
        Me.Panel1.ResumeLayout(False)
        Me.Panel1.PerformLayout()
        Me.Panel2.ResumeLayout(False)
        Me.grpCart.ResumeLayout(False)
        Me.grpFunctions.ResumeLayout(False)
        Me.grpItems.ResumeLayout(False)
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents pnlProducts As Panel
    Friend WithEvents Button3 As Button
    Friend WithEvents Button4 As Button
    Friend WithEvents Button2 As Button
    Friend WithEvents cmd1_1 As Button
    Friend WithEvents Panel1 As Panel
    Friend WithEvents Panel2 As Panel
    Friend WithEvents Button5 As Button
    Friend WithEvents Button6 As Button
    Friend WithEvents Button7 As Button
    Friend WithEvents Button8 As Button
    Friend WithEvents Button17 As Button
    Friend WithEvents Button18 As Button
    Friend WithEvents Button19 As Button
    Friend WithEvents Button20 As Button
    Friend WithEvents Button21 As Button
    Friend WithEvents Button22 As Button
    Friend WithEvents Button23 As Button
    Friend WithEvents cmd1_4 As Button
    Friend WithEvents Button25 As Button
    Friend WithEvents Button26 As Button
    Friend WithEvents Button27 As Button
    Friend WithEvents Button28 As Button
    Friend WithEvents Button29 As Button
    Friend WithEvents Button30 As Button
    Friend WithEvents Button31 As Button
    Friend WithEvents cmd1_3 As Button
    Friend WithEvents Button9 As Button
    Friend WithEvents Button10 As Button
    Friend WithEvents Button11 As Button
    Friend WithEvents Button12 As Button
    Friend WithEvents Button13 As Button
    Friend WithEvents Button14 As Button
    Friend WithEvents Button15 As Button
    Friend WithEvents cmd1_2 As Button
    Friend WithEvents cmdEditItems As Button
    Friend WithEvents cmdCash As Button
    Friend WithEvents cmdCard As Button
    Friend WithEvents cmdDiscount As Button
    Friend WithEvents cmdBeginEndShift As Button
    Friend WithEvents cmdClearOrder As Button
    Friend WithEvents lblLabelTotalCost As Label
    Friend WithEvents txtCart As TextBox
    Friend WithEvents lblTotalCost As Label
    Friend WithEvents grpCart As GroupBox
    Friend WithEvents grpFunctions As GroupBox
    Friend WithEvents grpItems As GroupBox
End Class
